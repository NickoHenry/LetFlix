$("#dropdown-btn").click(function () {
    if ( $(".dropdown-item").first().is(":hidden") ) {
        $(".dropdown-item").slideDown();
    } else {
        $(".dropdown-item").hide();
    }
});

$("#submit-btn").click(function(){
    var email = $("#email").val()
    var password = $("#password").val()
    var genderM = $('#male').prop('checked')
    var genderF = $('#female').prop('checked')
    var plan = $('#chosen-plan').val()
    var check = $('#terms').prop('checked')
    
    if(email == ''){
        alert("Please fill in your email!")
        return false
    }else if(email.indexOf("@") < 1 || !email.endsWith(".com")){
        alert("Please use a proper email format!")
        return false
    }if(password == ''){
        alert("Please fill in your password!")
        return false
    }else if(password.length < 8){
        alert("Your password must be longer than 8 characters!")
        return false
    }else if(!genderM && !genderF){
        alert("Please select your gender!")
        return false
    }else if(plan == null){
        alert("Please choose a subscription plan!")
        return false
    }else if(!check){
        alert("You need to accept the Terms and Conditions!")
        return false
    }


    return true
})
$("#dropdown-btn2").click(function () {
    if ( $(".dropdown-item2").first().is(":hidden") ) {
        $(".dropdown-item2").slideDown();
    } else {
        $(".dropdown-item2").hide();
    }
});